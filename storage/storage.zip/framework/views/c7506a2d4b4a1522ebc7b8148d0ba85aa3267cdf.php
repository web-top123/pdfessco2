<p>Your document can be found <a href="<?php echo e($link); ?>">here</a> .</p>
<?php /**PATH D:\xampp\htdocs\laravelpdf\resources\views\mail\test.blade.php ENDPATH**/ ?>
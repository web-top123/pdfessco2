<nav id="main-navigation">
    <div class="columns">

        <div class="column is-2 brand">

            <a href="<?php echo e(url()->current()); ?>">PDF<span>Glue</span></a>

        </div>

        <div class="column menu">

            <div class="links">
                    <a href="<?php echo e(url('/admin')); ?>">File Management</a>
                    <a href="<?php echo e(url('/admin/manage-users')); ?>">PdfGlue Users</a>
                    <a href="<?php echo e(url('/admin/manage-admins')); ?>">Administrative Users</a>
                    <a href="<?php echo e(url('/dashboard')); ?>">Create Document</a>
                    <a href="<?php echo e(url('/about')); ?>">About</a>
                    <a href="<?php echo e(url('/contact')); ?>">Contact</a>
            </div>
            <?php if(auth()->guard()->check()): ?>
            <div class="account" @click="navbar.dropdown = !navbar.dropdown">
                <span><?php echo e(Auth::user()->name); ?></span>
                <i v-if="!navbar.dropdown" class="fa fa-chevron-down"></i>
                <i v-if="navbar.dropdown" class="fa fa-chevron-up"></i>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <div v-show="navbar.dropdown" class="context-menu">
        <div class="context-menu-item">My Account</div>
        <div class="context-menu-item">Log Out</div>
    </div>
</nav>
<?php /**PATH D:\xampp\htdocs\laravelpdf\resources\views\layouts\navbar-admin.blade.php ENDPATH**/ ?>
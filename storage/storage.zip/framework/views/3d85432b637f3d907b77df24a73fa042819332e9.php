<div id="footer" class="presentation-footer <?php echo e(request()->path() === '/' ?  'welcome-footer' : ''); ?>">

    <div class="wrapper">
        <div class="left-side">All rights reserved by Pdfglue © <?php echo e(Carbon\Carbon::now()->format('Y')); ?></div>

        <div class="links">
            <a class="link <?php echo e(request()->path() === 'about' ? 'active' : ''); ?>" href="/about">
                <div class="text">
                    <p>About</p>
                </div>
            </a>
            <a class="link <?php echo e(request()->path() === 'contact-us' ? 'active' : ''); ?>" href="/contact-us">
                <div class="text">
                    <p>Contact</p>
                </div>
            </a>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\laravelpdf\resources\views/presentation/footer.blade.php ENDPATH**/ ?>
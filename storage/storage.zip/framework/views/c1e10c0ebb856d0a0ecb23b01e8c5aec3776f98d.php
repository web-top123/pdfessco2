

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('presentation.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="reset-wrapper">
    <div class="reset-container">
        <div class="reset-panel reset-default">
            <?php if(session('status')): ?>
            <div class="reset-heading"><span class="reset-title">Check Your Email</span></div>
            <?php else: ?>
            <div class="reset-heading"><span class="reset-title">Forgot Password</span></div>
            <?php endif; ?>

            <div class="reset-body">
                <?php if(session('status')): ?>
                <div class="alert-body">
                    <div class="confirm-reset">
                        Success! The password reset link was sent to your email address. It should be there momentarily.
                    </div>
                    <div class="confirm-reset boldit">
                        Please check your email and click the link in the message.  After 4 hours, the link will expire.
                    </div>

                    <a class="button back-login" href="/login">Back to Log In</a>
                </div>
                <?php endif; ?>
                <?php if(!session('status')): ?>
                <form class="form-horizontal" ref="forgotForm" method="POST" action="<?php echo e(route('password.email')); ?>" @submit="attemptForgot">
                    <?php echo e(csrf_field()); ?>

                    <div class="field<?php echo e($errors->has('email') ? ' has-error' : ''); ?>" :class="{'has-error' : forgotPass.errors.email.length}" >
                        <label class="label is-small" for="email" >EMAIL</label>
                        <input id="password" v-model="forgotPass.email" class="input is-medium" :class="{'has-error' : (forgotPass.errors.email.length>0), 'bounce-enter-active': failState === true}" name="email" type="email" placeholder="Your account's email address" @keyup="forgotPass.errors.email = ''" required>
                        <p class="help has-error error-message-flash" :class="{'bounce-enter-active': failState === true}" v-if="forgotPass.errors.email.length > 0">
                            <i class="fa fa-exclamation-circle" aria-hidden="true"></i>{{forgotPass.errors.email}}
                        </p>
                        <?php if($errors->has('email')): ?>
                        <p class="help has-error error-message-flash" v-if="forgotPass.errors.email.length===0">
                            <i class="fa fa-exclamation-circle" aria-hidden="true"></i><?php echo e($errors->first('email')); ?>

                        </p>
                        <?php endif; ?>
                    </div>

                    <div class="field footer-buttons">
                        <a class="button cancel-forgot" href="/login">Cancel</a>
                        <button @click.prevent="attemptForgot" class="button is-info" >
                            Send Reset Email
                        </button>
                    </div>
                    <div class="forgot-notification">We'll send you a link to reset your Pdfglue password!</div>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(mix('js/home.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravelpdf\resources\views\auth\passwords\email.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('presentation.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="reset-wrapper">
    <div class="reset-container">
        <div class="reset-panel reset-default">
            <div class="reset-heading"><span class="reset-title">Reset Password</span></div>

            <div class="reset-body">
                <form class="form-horizontal" method="POST" action="<?php echo e(route('password.request')); ?>" ref="resetForm">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="token" value="<?php echo e($token); ?>">
                    <div class="field<?php echo e($errors->has('email') ? ' has-error' : ''); ?>" :class="{'has-error' : forgotReset.errors.email.length}">
                        <label class="label is-small" for="email">EMAIL</label>
                        <input id="email" v-model="forgotReset.email" class="input is-medium" :class="{'has-error' : (forgotReset.errors.email.length>0), 'bounce-enter-active': failState === true}" name="email" type="email" placeholder="Your account's email address" value="<?php echo e(old('email')); ?>" @keyup="forgotReset.errors.email = ''" required autofocus>
                        <p class="help has-error error-message-flash" :class="{'bounce-enter-active': failState === true}" v-if="forgotReset.errors.email.length > 0">
                            <i class="fa fa-exclamation-circle" aria-hidden="true"></i>{{forgotReset.errors.email}}
                        </p>
                        <?php if($errors->has('email')): ?>
                        <p class="help has-error error-message-flash" v-if="forgotReset.errors.email.length===0">
                            <i class="fa fa-exclamation-circle" aria-hidden="true"></i><?php echo e($errors->first('email')); ?>

                        </p>
                        <?php endif; ?>
                    </div>

                    <div class="field<?php echo e($errors->has('password') ? ' has-error' : ''); ?>" :class="{'has-error' : forgotReset.errors.password.length}">
                        <label class="label is-small" for="password">NEW PASSWORD</label>
                        <input id="password" v-model="forgotReset.password" class="input is-medium" :class="{'has-error' : (forgotReset.errors.password.length>0), 'bounce-enter-active': failState === true}" name="password" type="password" placeholder="Your new password" @keyup="forgotReset.errors.password = ''" required>
                        <p class="help has-error error-message-flash" :class="{'bounce-enter-active': failState === true}" v-if="forgotReset.errors.password.length > 0">
                            <i class="fa fa-exclamation-circle" aria-hidden="true"></i>{{forgotReset.errors.password}}
                        </p>
                        <?php if($errors->has('password')): ?>
                        <p class="help has-error error-message-flash" v-if="forgotReset.errors.password.length===0">
                            <i class="fa fa-exclamation-circle" aria-hidden="true"></i><?php echo e($errors->first('password')); ?>

                        </p>
                        <?php endif; ?>
                    </div>

                    <div class="field<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>" :class="{'has-error' : forgotReset.errors.password_confirmation.length}">
                        <label class="label is-small" for="password-confirm">CONFIRM NEW PASSWORD</label>
                        <input id="password" v-model="forgotReset.password_confirmation" class="input is-medium" :class="{'has-error' : (forgotReset.errors.password_confirmation.length>0), 'bounce-enter-active': failState === true}" name="password_confirmation" type="password" placeholder="Your password confirmation" @keyup="forgotReset.errors.password_confirmation = ''" required>
                        <p class="help has-error error-message-flash" :class="{'bounce-enter-active': failState === true}" v-if="forgotReset.errors.password_confirmation.length > 0">
                            <i class="fa fa-exclamation-circle" aria-hidden="true"></i>{{forgotReset.errors.password_confirmation}}
                        </p>
                        <?php if($errors->has('password_confirmation')): ?>
                        <p class="help has-error error-message-flash" v-if="forgotReset.errors.password_confirmation.length===0">
                            <i class="fa fa-exclamation-circle" aria-hidden="true"></i><?php echo e($errors->first('password_confirmation')); ?>

                        </p>
                        <?php endif; ?>
                    </div>

                    <div class="field">
                        <button @click.prevent="attemptReset" class="button is-info">
                            Reset Password
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(mix('js/home.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravelpdf\resources\views\auth\passwords\reset.blade.php ENDPATH**/ ?>
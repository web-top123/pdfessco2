

<?php $__env->startSection('content'); ?>
        <navbar></navbar>
        <transition name="fade" mode="out-in">
            <keep-alive>
                <router-view></router-view>
            </keep-alive>
        </transition>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        var __Data = {
            user: Object.assign(<?php echo Auth::user(); ?>, { admin : <?php echo Auth::user()->can('manage'); ?> ,  superadmin: <?php echo Auth::user()->can('create_admins') ? 1 : 0; ?>, timeouts: <?php echo Auth::user()->timeouts(); ?> }),
        }

    </script>
    <script src="<?php echo e(mix('js/manage.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravelpdf\resources\views/manage.blade.php ENDPATH**/ ?>
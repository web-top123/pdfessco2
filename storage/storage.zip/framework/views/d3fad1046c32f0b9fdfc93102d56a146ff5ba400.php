<nav id="main-navigation">
    <div class="columns">

        <div class="column is-2 brand">
            <a href="/">PDF<span>Glue</span></a>
        </div>

        <div class="column menu">

            <div class="links">

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage')): ?>

                <a href="<?php echo e(url('/admin')); ?>" class="<?php echo e(!Request::is('admin') ?: 'active'); ?>">
                    <i class="fa fa-file-text-o" aria-hidden="true"></i>
                    File Management
                </a>

                <a href="<?php echo e(url('/admin/manage-users')); ?>" class="<?php echo e(!Request::is('admin/manage-users') ?: 'active'); ?>">
                    <i class="fa fa-user" aria-hidden="true"></i>
                    Pdfglue Users
                </a>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_admins')): ?>

                    <a href="<?php echo e(url('/admin/manage-admins')); ?>" class="<?php echo e(!Request::is('admin/manage-admins') ?: 'active'); ?>">
                        <i class="fa fa-briefcase" aria-hidden="true" style="padding-top: 2px;"></i>
                        Administrative Users
                    </a>

                    <?php endif; ?>

                <a href="<?php echo e(auth()->user()->isAdmin() ? url('admin#/dashboard') : url('dashboard')); ?>" class="<?php echo e(!Request::is('dashboard') ?: 'active'); ?>">
                    <i class="fa fa-pencil-square-o" aria-hidden="true" style="padding-top: 2px;"></i>
                    Create Document
                </a>

                <?php else: ?>
                    <a href="<?php echo e(url('/about')); ?>">
                        About
                    </a>

                    <a href="<?php echo e(url('/contact')); ?>">
                        Contact
                    </a>
                <?php endif; ?>

            </div>

            <?php if(auth()->guard()->check()): ?>

            <div id="navbar-dropdown" class="account" @click.prevent="navbar.dropdown = !navbar.dropdown" :class="{'active-dropdown' : navbar.dropdown}">
                <i class="fa fa-sort-down"></i>
                <span v-text="navbar.user.name"></span>
            </div>

            <?php else: ?>

            <div id="navbar-dropdown" class="account" @click.prevent="navbar.dropdown = !navbar.dropdown">
                <i v-if="!navbar.dropdown" class="fa fa-sort-down"></i>
                <i v-if="navbar.dropdown" class="fa fa-sort-up"></i>
                <span>Guest</span>
            </div>

            <?php endif; ?>

        </div>

    </div>
</nav>

<?php if(auth()->guard()->check()): ?>

<div v-show="navbar.dropdown" class="context-menu" v-on-click-outside="navbarOutside">
    <div class="context-menu-item"  @click="navbar.account = true">My Account</div>
    <div class="context-menu-item" @click="logout">Log Out</div>
</div>
<?php $__env->startPush('modals'); ?>
    <modal-account :show="navbar.account" :user="navbar.user" @close="navbar.account = false" @password="navbar.account = false; navbar.password = true" @user="updateUser"></modal-account>
    <modal-password :show="navbar.password" :user="navbar.user" @close="navbar.password = false"></modal-password>
<?php $__env->stopPush(); ?>

<?php else: ?>

<div v-show="navbar.dropdown" class="context-menu" >
    <div class="context-menu-item" :errors="navbar.errors" @click="navbar.loginModal = true">Login</div>
    <div class="context-menu-item" :errors="navbar.errors" @click="navbar.registerModal = true">Register</div>
</div>
<?php $__env->startPush('modals'); ?>
    <modal-login :show="navbar.loginModal" @close="navbar.loginModal = false" @register="navbar.loginModal = false; navbar.registerModal = true" @login="login"></modal-login>
    <modal-register :show="navbar.registerModal" @close="navbar.registerModal = false" @register="register"></modal-register>
<?php $__env->stopPush(); ?>

<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        var user = <?php echo auth()->user() ? auth()->user() : "{}"; ?>

        var token = "<?php echo e(csrf_token()); ?>"
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\xampp\htdocs\laravelpdf\resources\views\layouts\navbar.blade.php ENDPATH**/ ?>
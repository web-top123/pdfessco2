

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('presentation.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="reset-wrapper">
    <div class="reset-container">
        <div class="reset-panel reset-default">
            <div class="reset-heading"><span class="reset-title">Login</span></div>

            <div class="reset-body">
                <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <div class="field<?php echo e($errors->has('email') ? ' has-error' : ''); ?>" :class="{'has-error' : login.errors.email.length}" >
                        <label class="label is-small" for="email">EMAIL</label>
                        <input id="email" v-model="login.email" class="input is-medium" :class="{'has-error' : (login.errors.email.length>0), 'bounce-enter-active': failState === true}" name="email" type="email" placeholder="example@domain.com" value="<?php echo e(old('email')); ?>" @keyup="login.errors.email = ''" required>
                        <p class="help has-error error-message-flash" :class="{'bounce-enter-active':failState === true}" v-if="login.errors.email.length > 0">
                            <i class="fa fa-exclamation-circle" aria-hidden="true"></i>{{login.errors.email}}
                        </p>
                    </div>

                    <div class="field<?php echo e($errors->has('password') ? ' has-error' : ''); ?>" :class="{'has-error' : login.errors.password.length}" >
                        <label class="label is-small" for="password">PASSWORD</label>
                        <input id="password" v-model="login.password" class="input is-medium" :class="{'has-error' : (login.errors.password.length>0), 'bounce-enter-active': failState === true}" name="password" type="password" placeholder="Must have at least 6 characters" @keyup="login.errors.password = ''" required>
                        <p class="help has-error error-message-flash" :class="{'bounce-enter-active':failState === true}" v-if="login.errors.password.length>0"><i class="fa fa-exclamation-circle" aria-hidden="true"></i>{{login.errors.password}}</p>
                    </div>

                    <div class="field is-grouped remember-me">
                        <span>
                            <input type="checkbox" name="remember" class="styled-checkbox" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label for="remember"><span class="rmb" >Remember Me</span></label>
                        </span>
                        <a class="" href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
                    </div>

                    <div class="field">
                        <button type="submit" class="button-base fill main-button upload-main-button">
                            Login
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/home.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravelpdf\resources\views\auth\login.blade.php ENDPATH**/ ?>
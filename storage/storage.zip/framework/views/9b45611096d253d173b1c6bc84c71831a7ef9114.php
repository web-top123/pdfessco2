<p> <?php echo e($text); ?> </p>
<?php /**PATH D:\xampp\htdocs\laravelpdf\resources\views\mail\contact.blade.php ENDPATH**/ ?>
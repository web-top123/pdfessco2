



<?php $__env->startSection('content'); ?>

    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>

        var categories = <?php echo $categories; ?>;
        var list = <?php echo $list; ?>;

    </script>
    <script src="<?php echo e(mix('js/manage.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravelpdf\resources\views\manage-2.blade.php ENDPATH**/ ?>